import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "./App.css";

const ServiceResults = () => {
  const { type } = useParams();
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get(`http://localhost:5000/${type}`)
      .then((res) => setData(res.data));
  }, [type]);

  return (
    <div className="results-container">
      <h2>{type.charAt(0).toUpperCase() + type.slice(1)}s Available</h2>

      {data.length === 0 && <p>No data found</p>}

      <div className="results-grid">
        {data.map((person) => (
          <div className="result-card" key={person._id}>
            <h3>{person.name}</h3>
            <p><b>Experience:</b> {person.experience} years</p>
            <p><b>Phone:</b> {person.phone}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceResults;
