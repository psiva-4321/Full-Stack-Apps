import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./App.css";

const Service = () => {
    const [search, setSearch] = useState("");
    const navigate = useNavigate();

    const handleSearch = () => {
        if (search.trim() !== "") {
            navigate(`/${search.toLowerCase()}`);
        }
    };

    return (
        <div className="services-container">
            <h2 className="services-title">Our Services</h2>

            {/* Search Box */}
            <div className="search-box">
                <input
                    type="text"
                    placeholder="Search plumber, electrician..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                <button onClick={handleSearch}>Search</button>
            </div>

            {/* Cards */}
            <div className="services-cards">
                <div
                    className="service-card"
                    onClick={() => navigate("/electrician")}
                >
                    <div className="service-icon">⚡</div>
                    <h3>Electrician</h3>
                    <p>Electrical wiring & repairs</p>
                </div>

                <div
                    className="service-card"
                    onClick={() => navigate("/plumber")}
                >
                    <div className="service-icon">🔧</div>
                    <h3>Plumber</h3>
                    <p>Pipe fixing & leakage repair</p>
                </div>

                <div
                    className="service-card"
                    onClick={() => navigate("/carpenter")}
                >
                    <div className="service-icon">🔨</div>
                    <h3>Carpenter</h3>
                    <p>Furniture & wood works</p>
                </div>

                <div className="service-card">
                    onClick={() => navigate("/painter")}
                    <div className="service-icon">🎨</div>
                    <h3>Painter</h3>
                    <p>Interior & exterior painting</p>
                </div>
            </div>
        </div>
    );
};

export default Service;
